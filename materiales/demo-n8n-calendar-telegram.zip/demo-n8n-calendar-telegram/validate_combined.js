
const AUTHORIZED_CHAT_ID = 'REEMPLAZAR_CHAT_ID';
const ZONE = 'America/Argentina/Buenos_Aires';

const msg = $json.message ?? {};
const chatId = String(msg.chat?.id ?? '');
const chatType = String(msg.chat?.type ?? '');
const rawText = String(msg.text ?? '').trim();
const command = rawText.split(/\s+/)[0].toLowerCase().replace(/@[a-z0-9_]+$/i, '');

// Seguridad: no responder a grupos ni a chats distintos del autorizado.
if (chatType !== 'private' || chatId !== AUTHORIZED_CHAT_ID) return [];

const start = $now.setZone(ZONE).startOf('day');
const end = start.plus({ days: 7 });

let mode = null;
let immediateText = null;
if (command === '/semana_clasica') mode = 'classic';
else if (command === '/semana_ia') mode = 'ia';
else {
  immediateText = [
    'Comandos disponibles:',
    '/semana_clasica — resumen con plantilla fija',
    '/semana_ia — resumen redactado con un único paso de IA',
  ].join('\n');
}

return [{
  json: {
    chatId,
    mode,
    proceed: mode !== null,
    immediateText,
    zone: ZONE,
    periodStart: start.toISO(),
    periodEnd: end.toISO(),
  }
}];
