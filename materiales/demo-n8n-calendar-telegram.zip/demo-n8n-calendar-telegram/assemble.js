
const base = $('Normalizar y calcular hechos').first().json;
const current = $input.first()?.json ?? {};

function extractText(obj) {
  if (!obj) return null;
  if (typeof obj === 'string') return obj.trim() || null;
  for (const key of ['output_text','text','content','response','message']) {
    const v = obj[key];
    if (typeof v === 'string' && v.trim()) return v.trim();
    if (v && typeof v === 'object') {
      const nested = extractText(v);
      if (nested) return nested;
    }
  }
  for (const key of ['output','data','choices']) {
    const v = obj[key];
    if (Array.isArray(v)) {
      for (const item of v) {
        const nested = extractText(item);
        if (nested) return nested;
      }
    }
  }
  return null;
}

let summary = typeof current.summary === 'string' ? current.summary.trim() : null;
if (!summary && base.mode === 'ia') summary = extractText(current);
if (!summary) {
  summary = base.mode === 'ia'
    ? 'No se pudo generar el resumen con IA. Se conserva abajo la lista verificable de eventos.'
    : base.fixedSummary;
}

const header = base.mode === 'ia' ? 'RESUMEN SEMANAL CON IA' : 'RESUMEN SEMANAL SIN IA';
const text = base.status === 'calendar_error'
  ? `${header}\n\n${summary}`
  : `${header}\n\n${summary}\n\nLISTA VERIFICABLE DE EVENTOS\n${base.exactList}`;

return [{json:{chatId:base.chatId,text}}];
