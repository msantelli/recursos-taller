
let summary = $json.fixedSummary;
if ($json.mode === 'ia' && $json.status !== 'ok') {
  summary = `${$json.fixedSummary}\nEl paso de IA no se ejecutó porque la consulta del calendario falló.`;
}
return [{json:{summary}}];
