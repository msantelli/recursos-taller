# Demostración didáctica: n8n + Google Calendar + Telegram

Proyecto separado para comparar un workflow clásico y otro con un único paso de IA. No contiene ni modifica archivos de `clase-agentes-autonomos`.

## Archivos

- `00-demo-comparativa-un-bot.json`: recomendado. Un único `Telegram Trigger` y dos comandos: `/semana_clasica` y `/semana_ia`.
- `01-workflow-clasico-on-demand.json`: versión independiente. Comando `/semana`.
- `02-workflow-ia-on-demand.json`: versión independiente. Comando `/semana`.
- `PROMPT-IA.txt`: prompt separado para mostrar en clase.

No actives simultáneamente los dos workflows independientes con el mismo bot: Telegram admite un solo webhook por bot. Para compararlos en simultáneo, usá el archivo `00`.

## Arquitectura recomendada

`Telegram Trigger → validar chat/comando → Google Calendar → normalizar y calcular hechos → bifurcación clásico/IA → adjuntar lista exacta → dividir → Telegram`

La IA no decide cuándo ejecutarse, qué fuente consultar, qué herramientas usar, el orden de ejecución ni el canal de salida. Solo redacta un resumen a partir de hechos calculados.

## Nodos y credenciales

### Comunes

1. **Telegram Trigger** — credencial `Telegram API`.
2. **Code: Validar comando y rango** — limita el acceso al chat privado autorizado y calcula el período.
3. **IF: ¿Comando ejecutable?**.
4. **Google Calendar: Get Many** — credencial `Google Calendar OAuth2 API`.
5. **Code: Normalizar y calcular hechos** — ordena, deduplica por ID, distingue eventos horarios/día completo, calcula carga, superposiciones y ventanas libres.
6. **Code: Adjuntar lista exacta** — une el resumen con la lista generada por código.
7. **Code: Dividir mensajes largos** — partes de hasta 3900 caracteres.
8. **Telegram: Send Message** — misma credencial de Telegram.

### Solo versión con IA

- **OpenAI: Text → Generate a model response / Message a model** — credencial `OpenAI API`. Es el único nodo de IA.

## 1. Crear el bot de Telegram

1. Abrí el chat oficial `@BotFather`.
2. Ejecutá `/newbot`.
3. Indicá un nombre visible y un nombre de usuario terminado en `bot`.
4. Copiá el token una sola vez.
5. En n8n: **Credentials → New → Telegram API**; pegá el token en **Access Token**.
6. En BotFather, configurá comandos con `/setcommands`:

   ```text
   semana_clasica - Resumen semanal sin IA
   semana_ia - Resumen semanal con IA
   ayuda - Mostrar comandos
   ```

7. No agregues el bot a grupos. El workflow exige `chat.type = private` y un `chat.id` concreto.
8. Para conocer tu `chat.id`, ejecutá **Listen for test event** en `Telegram Trigger`, enviá `/start` al bot e inspeccioná `message.chat.id`.
9. Reemplazá `REEMPLAZAR_CHAT_ID` dentro del nodo **Validar comando y rango**.

El token queda en la credencial de n8n, nunca en el JSON ni en un repositorio.

## 2. Crear un calendario exclusivo de prueba

1. En Google Calendar, creá un calendario secundario llamado, por ejemplo, `Demo n8n — agenda semanal`.
2. Abrí **Configuración e integración** y copiá su **ID del calendario**.
3. En cada nodo Google Calendar, reemplazá `REEMPLAZAR_CALENDAR_ID_DE_PRUEBA`.
4. No uses el calendario principal durante la clase.

Eventos sugeridos para probar:

- Lunes 10:00–11:00: `Clase de prueba`.
- Lunes 10:30–11:30: `Reunión superpuesta`.
- Martes: `Entrega de trabajos`, día completo.
- Miércoles 09:00–12:00: `Seminario`.
- Miércoles 14:00–15:00: `Tutoría`.
- Viernes 17:00–18:00: `Cierre semanal`.

Para probar deduplicación real sin borrar eventos legítimos, fijá la salida del nodo Calendar y duplicá manualmente un mismo ítem con el mismo `id`. El código no fusiona dos eventos distintos que tengan títulos y horarios iguales.

## 3. Conectar Google Calendar

### n8n Cloud

Podés usar el OAuth administrado por n8n si aparece disponible. Para permisos mínimos estrictos, preferí OAuth personalizado y scope de solo lectura.

### n8n autohospedado

1. Creá un proyecto en Google Cloud Console.
2. Habilitá **Google Calendar API**.
3. Configurá la pantalla de consentimiento OAuth.
4. Creá un cliente OAuth de tipo **Web application**.
5. Copiá desde la credencial de n8n la **OAuth Redirect URL** y registrala exactamente en Google.
6. En n8n creá una credencial **Google Calendar OAuth2 API** con el Client ID y Client Secret.
7. Activá scopes personalizados y usá solo:

   ```text
   https://www.googleapis.com/auth/calendar.readonly
   ```

8. Autorizá únicamente la cuenta que contiene el calendario de prueba.

## 4. Conectar OpenAI

1. Creá una clave específica para este proyecto o entorno de demostración.
2. En n8n: **Credentials → New → OpenAI API**.
3. Pegá la clave en la credencial, no en el nodo Code ni en el JSON.
4. Asigná la credencial al nodo amarillo **ÚNICO PASO IA**.
5. El JSON propone `gpt-5-mini`. Si no aparece en tu cuenta o versión de n8n, seleccioná un modelo pequeño de texto disponible en la lista del nodo.
6. Configurá un límite de gasto bajo para la demostración.

## 5. Expresiones exactas para los próximos siete días

Inicio: comienzo del día local en Buenos Aires.

```text
={{ $now.setZone('America/Argentina/Buenos_Aires').startOf('day').toISO() }}
```

Fin exclusivo: comienzo del día siete días después.

```text
={{ $now.setZone('America/Argentina/Buenos_Aires').startOf('day').plus({ days: 7 }).toISO() }}
```

Además, en **Workflow Settings → Timezone**, configurá:

```text
America/Argentina/Buenos_Aires
```

El JSON ya incluye esta zona horaria.

## 6. Manejo de casos límite

- **Calendario vacío:** el nodo Calendar tiene `Always Output Data`; se genera `Sin eventos en el período`.
- **Eventos de día completo:** se leen desde `start.date`/`end.date`; el final de Google es exclusivo.
- **Eventos sin hora o malformados:** aparecen como `Hora no disponible` o `Fecha no disponible`.
- **Duplicados:** se eliminan repeticiones con el mismo `event.id`; el fallback usa `iCalUID + inicio + título`.
- **Eventos recurrentes:** se expanden a instancias mediante `singleEvents` y `recurringEventHandling=expand`.
- **Errores de Calendar:** tres reintentos y salida de error legible; el paso de IA se omite.
- **Errores de OpenAI:** dos reintentos; si falla, se envía una advertencia y siempre queda la lista exacta.
- **Mensajes largos:** se dividen a 3900 caracteres, por debajo del límite de 4096 de Telegram.
- **Seguridad del chat:** cualquier chat que no coincida con `REEMPLAZAR_CHAT_ID` se descarta sin respuesta.
- **Ventanas libres:** lunes a viernes, 09:00–18:00, mínimo 60 minutos. Los eventos de día completo bloquean toda esa franja.

## 7. Prueba manual antes de activar

1. Importá `00-demo-comparativa-un-bot.json`.
2. Asigná las tres credenciales: Telegram en Trigger y Send Message; Google Calendar; OpenAI.
3. Reemplazá Chat ID y Calendar ID.
4. Confirmá la zona horaria del workflow.
5. Sin activar el workflow, abrí `Telegram Trigger` y pulsá **Listen for test event**.
6. En Telegram enviá `/semana_clasica`.
7. Revisá, nodo por nodo:
   - período ISO;
   - eventos devueltos;
   - lista ordenada;
   - mensajes enviados.
8. Repetí con `/semana_ia` y verificá que solo aparece una ejecución del nodo amarillo de IA.
9. Fijá la salida de Google Calendar para repetir pruebas downstream sin consultar nuevamente la API.
10. Probá los casos límite:
    - calendario vacío;
    - evento de día completo;
    - dos eventos superpuestos;
    - salida Calendar duplicada con el mismo ID;
    - credencial OpenAI temporalmente inválida;
    - muchos eventos o `MAX=500` en el nodo divisor.
11. Solo después activá el workflow para registrar el webhook de producción.

En una instalación autohospedada, el `Telegram Trigger` necesita una URL pública HTTPS correctamente configurada; `localhost` no es accesible para Telegram.

## 8. Cómo mostrarlo en clase

El archivo comparativo contiene notas visuales:

- **TRAMO FIJO** a la izquierda: activación, autorización, Calendar y procesamiento.
- **SIN IA**: plantilla fija.
- **ÚNICO PASO DE IA**: un único nodo amarillo.
- **TRAMO FIJO** a la derecha: lista verificable, división y Telegram.

Ejecutá primero `/semana_clasica` y después `/semana_ia`. En la vista de ejecución, resaltá que el segundo recorrido solo incorpora el nodo de redacción: no existe un `AI Agent`, no hay herramientas entregadas al modelo y no hay planificación autónoma.

## 9. Volver a la programación automática

Para recuperar la versión original de los lunes a las 08:00:

1. Sustituí `Telegram Trigger` y la validación de comando por `Schedule Trigger`.
2. Elegí intervalo semanal, lunes, 08:00.
3. Conservá la zona horaria del workflow.
4. Definí el `chatId` autorizado como valor fijo en el nodo Telegram.

El resto del recorrido no cambia.

## Fuentes oficiales consultadas

- n8n: Telegram Trigger, Telegram, Google Calendar, Google OAuth2, OpenAI, fechas/Luxon, zonas horarias, Schedule Trigger y pinning de datos: https://docs.n8n.io/
- Google Calendar Events list y scopes: https://developers.google.com/workspace/calendar/api/v3/reference/events/list
- Telegram Bot API y tutorial de BotFather: https://core.telegram.org/bots/api y https://core.telegram.org/bots/tutorial
- OpenAI modelos y seguridad de claves: https://developers.openai.com/api/docs/models y https://help.openai.com/en/articles/5112595-best-practices-for-api-key-safety
