
const ctx = $('Validar comando y rango').first().json;
const ZONE = ctx.zone;
const raw = $input.all().map(i => i.json ?? {});

function errText(value) {
  if (!value) return '';
  if (typeof value === 'string') return value;
  if (value.message) return String(value.message);
  try { return JSON.stringify(value); } catch { return String(value); }
}

const errorItem = raw.find(x => x.error || x.errorMessage || x.statusCode >= 400);
const apiError = errorItem ? (errText(errorItem.error) || errText(errorItem.errorMessage) || errText(errorItem)) : null;

function addDays(dateStr, days) {
  const d = new Date(`${dateStr}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}
function dateKeyFromDate(d) {
  const parts = new Intl.DateTimeFormat('en-CA', {timeZone: ZONE, year:'numeric', month:'2-digit', day:'2-digit'}).formatToParts(d);
  const o = Object.fromEntries(parts.map(p => [p.type, p.value]));
  return `${o.year}-${o.month}-${o.day}`;
}
function humanDateFromKey(key) {
  const d = new Date(`${key}T12:00:00Z`);
  const s = new Intl.DateTimeFormat('es-AR', {timeZone:'UTC', weekday:'long', day:'2-digit', month:'2-digit'}).format(d);
  return s.charAt(0).toUpperCase() + s.slice(1);
}
function humanTime(d) {
  return new Intl.DateTimeFormat('es-AR', {timeZone: ZONE, hour:'2-digit', minute:'2-digit', hour12:false}).format(d);
}
function minutesLabel(mins) {
  const h = Math.floor(mins / 60).toString().padStart(2,'0');
  const m = (mins % 60).toString().padStart(2,'0');
  return `${h}:${m}`;
}
function eventLooksReal(e) {
  return Boolean(e.id || e.iCalUID || e.start || e.end || e.summary || e.htmlLink);
}

// Quita únicamente repeticiones del mismo objeto de Calendar. No fusiona eventos distintos
// que casualmente tengan el mismo título y horario.
const seen = new Set();
const events = [];
for (const e of raw.filter(eventLooksReal)) {
  if (e.status === 'cancelled') continue;
  const startToken = e.start?.dateTime || e.start?.date || '';
  const key = e.id || `${e.iCalUID || ''}|${startToken}|${e.summary || ''}`;
  if (seen.has(key)) continue;
  seen.add(key);
  events.push(e);
}

const normalized = events.map((e, index) => {
  const title = e.summary || '(Sin título)';
  const link = e.htmlLink || '';
  const allDay = Boolean(e.start?.date && !e.start?.dateTime);
  let startMs = null, endMs = null, dateKey = null, schedule = 'Hora no disponible';

  if (allDay) {
    dateKey = e.start.date;
    startMs = Date.parse(`${e.start.date}T00:00:00Z`);
    const endExclusive = e.end?.date || addDays(e.start.date, 1);
    endMs = Date.parse(`${endExclusive}T00:00:00Z`);
    const lastDay = addDays(endExclusive, -1);
    schedule = lastDay === e.start.date ? 'Todo el día' : `Todo el día hasta ${humanDateFromKey(lastDay)}`;
  } else if (e.start?.dateTime) {
    const s = new Date(e.start.dateTime);
    const en = new Date(e.end?.dateTime || e.start.dateTime);
    if (!Number.isNaN(s.getTime())) {
      startMs = s.getTime();
      endMs = Number.isNaN(en.getTime()) ? startMs : en.getTime();
      dateKey = dateKeyFromDate(s);
      schedule = `${humanTime(s)}–${humanTime(en)}`;
    }
  }

  return {
    sourceIndex: index,
    id: e.id || null,
    iCalUID: e.iCalUID || null,
    title,
    link,
    allDay,
    startMs,
    endMs,
    dateKey,
    schedule,
    rawStart: e.start || null,
    rawEnd: e.end || null,
  };
});

normalized.sort((a,b) => {
  const av = a.startMs ?? Number.MAX_SAFE_INTEGER;
  const bv = b.startMs ?? Number.MAX_SAFE_INTEGER;
  return av - bv || a.title.localeCompare(b.title, 'es');
});

const exactLines = normalized.map((e, i) => {
  const day = e.dateKey ? humanDateFromKey(e.dateKey) : 'Fecha no disponible';
  const link = e.link || '(Sin enlace)';
  return `${i+1}. ${day} · ${e.schedule} · ${e.title}\n   ${link}`;
});
const exactList = exactLines.length ? exactLines.join('\n') : 'Sin eventos en el período.';

const startDate = ctx.periodStart.slice(0,10);
const dayKeys = Array.from({length:7}, (_,i) => addDays(startDate, i));
const offsetMatch = ctx.periodStart.match(/([+-]\d\d:\d\d|Z)$/);
const offset = offsetMatch ? offsetMatch[1] : '-03:00';
const WORK_START = 9 * 60;
const WORK_END = 18 * 60;
const MIN_FREE = 60;
const busy = Object.fromEntries(dayKeys.map(k => [k, []]));
const counts = Object.fromEntries(dayKeys.map(k => [k, 0]));

function dayBoundary(key, minute) {
  const hh = Math.floor(minute/60).toString().padStart(2,'0');
  const mm = (minute%60).toString().padStart(2,'0');
  return Date.parse(`${key}T${hh}:${mm}:00${offset}`);
}
function addBusy(day, start, end) {
  if (!busy[day] || end <= start) return;
  busy[day].push([start,end]);
}

for (const e of normalized) {
  if (e.allDay && e.rawStart?.date) {
    const endExclusive = e.rawEnd?.date || addDays(e.rawStart.date,1);
    for (let d=e.rawStart.date; d < endExclusive; d=addDays(d,1)) {
      if (counts[d] !== undefined) {
        counts[d] += 1;
        addBusy(d, WORK_START, WORK_END);
      }
    }
    continue;
  }
  if (e.startMs == null || e.endMs == null) continue;
  for (const day of dayKeys) {
    const dayStart = dayBoundary(day, 0);
    const nextDay = Date.parse(`${addDays(day,1)}T00:00:00${offset}`);
    if (e.startMs < nextDay && e.endMs > dayStart) counts[day] += 1;
    const workStartMs = dayBoundary(day, WORK_START);
    const workEndMs = dayBoundary(day, WORK_END);
    const s = Math.max(e.startMs, workStartMs);
    const en = Math.min(e.endMs, workEndMs);
    if (en > s) addBusy(day, Math.round((s-workStartMs)/60000)+WORK_START, Math.round((en-workStartMs)/60000)+WORK_START);
  }
}

function mergedIntervals(list) {
  const sorted = [...list].sort((a,b)=>a[0]-b[0]);
  const out=[];
  for (const int of sorted) {
    if (!out.length || int[0] > out[out.length-1][1]) out.push([...int]);
    else out[out.length-1][1] = Math.max(out[out.length-1][1], int[1]);
  }
  return out;
}

const occupied = {};
const freeWindows = [];
for (const day of dayKeys) {
  const merged = mergedIntervals(busy[day]);
  occupied[day] = merged.reduce((sum,[s,e])=>sum+e-s,0);
  const dow = new Date(`${day}T12:00:00Z`).getUTCDay();
  if (dow === 0 || dow === 6) continue;
  let cursor = WORK_START;
  for (const [s,e] of merged) {
    if (s-cursor >= MIN_FREE) freeWindows.push({day,start:cursor,end:s,duration:s-cursor});
    cursor = Math.max(cursor,e);
  }
  if (WORK_END-cursor >= MIN_FREE) freeWindows.push({day,start:cursor,end:WORK_END,duration:WORK_END-cursor});
}
freeWindows.sort((a,b)=>b.duration-a.duration || a.day.localeCompare(b.day) || a.start-b.start);

const timed = normalized.filter(e => !e.allDay && e.startMs != null && e.endMs != null && e.endMs > e.startMs);
const overlaps=[];
for (let i=0;i<timed.length;i++) {
  for (let j=i+1;j<timed.length;j++) {
    const a=timed[i], b=timed[j];
    if (a.startMs < b.endMs && b.startMs < a.endMs) {
      overlaps.push(`${a.title} (${humanTime(new Date(a.startMs))}–${humanTime(new Date(a.endMs))}) / ${b.title} (${humanTime(new Date(b.startMs))}–${humanTime(new Date(b.endMs))})`);
    }
  }
}

let maxOccupied = Math.max(...dayKeys.map(d=>occupied[d] || 0));
let heavy = dayKeys.filter(d => (occupied[d] || 0) === maxOccupied && ((occupied[d] || 0)>0 || counts[d]>0));
if (!heavy.length) {
  const maxCount = Math.max(...dayKeys.map(d=>counts[d] || 0));
  heavy = maxCount ? dayKeys.filter(d=>counts[d]===maxCount) : [];
}
const heavyText = heavy.length
  ? heavy.map(d=>`${humanDateFromKey(d)} (${counts[d]} evento(s), ${occupied[d]} min ocupados entre 09:00 y 18:00)`).join('; ')
  : 'No hay días cargados.';
const overlapText = overlaps.length ? overlaps.join('; ') : 'No se detectaron superposiciones horarias.';
const freeText = freeWindows.length
  ? freeWindows.slice(0,5).map(w=>`${humanDateFromKey(w.day)} ${minutesLabel(w.start)}–${minutesLabel(w.end)}`).join('; ')
  : 'No se detectaron ventanas libres de al menos 60 minutos dentro de 09:00–18:00 de lunes a viernes.';

const facts = [
  `Superposiciones: ${overlapText}`,
  `Días con mayor carga: ${heavyText}`,
  `Ventanas libres: ${freeText}`,
  'Criterio de ventanas libres: lunes a viernes, 09:00–18:00, mínimo 60 minutos; un evento de día completo bloquea toda esa franja.',
].join('\n');

let status = 'ok';
let fixedSummary;
if (apiError) {
  status = 'calendar_error';
  fixedSummary = `No se pudo consultar Google Calendar. Detalle: ${apiError}`;
} else if (!normalized.length) {
  fixedSummary = `No hay eventos en los próximos 7 días (${humanDateFromKey(startDate)} a ${humanDateFromKey(addDays(startDate,6))}).`;
} else {
  fixedSummary = `Agenda de los próximos 7 días: ${normalized.length} evento(s), desde ${humanDateFromKey(startDate)} hasta ${humanDateFromKey(addDays(startDate,6))}.`;
}

const aiPrompt = [
  `PERÍODO: ${ctx.periodStart} hasta ${ctx.periodEnd} (fin exclusivo).`,
  `ZONA HORARIA: ${ZONE}.`,
  '',
  'HECHOS CALCULADOS POR CÓDIGO:',
  facts,
  '',
  'EVENTOS NORMALIZADOS OBTENIDOS DE GOOGLE CALENDAR:',
  JSON.stringify(normalized.map(e=>({title:e.title, allDay:e.allDay, date:e.dateKey, schedule:e.schedule, link:e.link})), null, 2),
].join('\n');

return [{json:{
  ...ctx,
  status,
  apiError,
  eventCount: normalized.length,
  normalizedEvents: normalized,
  exactList,
  facts,
  fixedSummary,
  aiPrompt,
  useAI: ctx.mode === 'ia' && status === 'ok',
}}];
