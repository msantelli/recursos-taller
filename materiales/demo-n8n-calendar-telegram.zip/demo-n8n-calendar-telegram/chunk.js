
const MAX = 3900; // margen respecto del límite de 4096 caracteres de Telegram
const source = String($json.text ?? '');
const chatId = String($json.chatId ?? '');
const lines = source.split('\n');
const chunks = [];
let current = '';

function pushCurrent() {
  if (current) chunks.push(current);
  current = '';
}
for (const line of lines) {
  const addition = current ? `\n${line}` : line;
  if ((current + addition).length <= MAX) {
    current += addition;
    continue;
  }
  pushCurrent();
  if (line.length <= MAX) current = line;
  else {
    for (let i=0;i<line.length;i+=MAX) chunks.push(line.slice(i,i+MAX));
  }
}
pushCurrent();
const total = chunks.length || 1;
return (chunks.length ? chunks : ['Sin contenido']).map((text,index)=>({
  json:{chatId,text: total > 1 ? `Parte ${index+1}/${total}\n\n${text}` : text}
}));
